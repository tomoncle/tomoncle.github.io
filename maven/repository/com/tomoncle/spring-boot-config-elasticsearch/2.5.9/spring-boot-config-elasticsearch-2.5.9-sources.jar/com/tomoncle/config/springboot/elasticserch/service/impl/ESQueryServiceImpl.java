/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.elasticserch.service.impl;

import com.tomoncle.config.springboot.elasticserch.service.ESQueryService;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.ParsedStringTerms;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.springframework.data.domain.*;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.core.ElasticsearchRestTemplate;
import org.springframework.data.elasticsearch.core.SearchHit;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.StringQuery;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author tomoncle
 */
@Component
public class ESQueryServiceImpl<T> implements ESQueryService<T> {
    private final ElasticsearchRestTemplate template;

    public ESQueryServiceImpl(ElasticsearchRestTemplate template) {
        this.template = template;
    }

    @Override
    public Map<String, List<? extends Terms.Bucket>> map(QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder, Class<T> entityClass) {
        Aggregations aggregations = this.aggregations(queryBuilder, aggregationBuilder, entityClass);
        Map<String, List<? extends Terms.Bucket>> map = new LinkedHashMap<>();
        if (null == aggregations) {
            return map;
        }
        List<Aggregation> aggregationsList = aggregations.asList();
        for (Aggregation aggregation : aggregationsList) {
            map.put(aggregation.getName(), ((ParsedStringTerms) aggregation).getBuckets());
        }
        return map;
    }

    @Override
    public Aggregations aggregations(QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder, Class<T> entityClass) {
        Assert.notNull(entityClass, "'entityClass' cannot be 'null'");
        Document document = entityClass.getAnnotation(Document.class);
        Assert.notNull(document, entityClass.getSimpleName() + " NotFound 'Document' annotation.");
        NativeSearchQuery nativeSearchQuery = this.nativeSearchQuery(queryBuilder, aggregationBuilder);
        SearchHits<T> searchHits = template.search(nativeSearchQuery, entityClass, IndexCoordinates.of(document.indexName()));
        return searchHits.getAggregations();
    }

    @Override
    public Aggregations aggregations(QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder, Class<T> entityClass, String indexName) {
        Assert.notNull(entityClass, "'entityClass' cannot be 'null'");
        NativeSearchQuery nativeSearchQuery = this.nativeSearchQuery(queryBuilder, aggregationBuilder);
        SearchHits<T> searchHits = template.search(nativeSearchQuery, entityClass, IndexCoordinates.of(indexName));
        return searchHits.getAggregations();
    }

    @Override
    public SearchHits<T> searchHits(String index, Class<T> entityClass, NativeSearchQuery query) {
        return template.search(query, entityClass, IndexCoordinates.of(index));
    }

    @Override
    public SearchHits<T> searchHits(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort) {
        StringQuery query = new StringQuery(param, pageable, sort);
        return template.search(query, entityClass, IndexCoordinates.of(index));
    }

    @Override
    public SearchHits<T> searchHits(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort, String... fields) {
        if (null == fields || fields.length == 0) {
            return this.searchHits(index, entityClass, param, pageable, sort);
        }
        StringQuery query = new StringQuery(param, pageable, sort);
        query.addFields(fields);
        return template.search(query, entityClass, IndexCoordinates.of(index));
    }

    @Override
    public List<T> list(String index, Class<T> entityClass, NativeSearchQuery query) {
        return page(index, entityClass, query).getContent();
    }

    @Override
    public List<T> list(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort, String... fields) {
        return page(index, entityClass, param, pageable, sort, fields).getContent();
    }

    @Override
    public List<T> list(String index, Class<T> entityClass, String param, Pageable pageable) {
        return page(index, entityClass, param, pageable).getContent();
    }

    @Override
    public Page<T> page(String index, Class<T> entityClass, NativeSearchQuery query) {
        SearchHits<T> searchHits = this.searchHits(index, entityClass, query);
        List<SearchHit<T>> hits = searchHits.getSearchHits();
        List<T> list = new ArrayList<>();
        for (SearchHit<T> hit : hits) {
            list.add(hit.getContent());
        }
        PageRequest pageable = PageRequest.of(query.getPageable().getPageNumber(), query.getPageable().getPageSize());
        if (null != query.getSort()) {
            pageable.withSort(query.getSort());
        }
        return new PageImpl<T>(list, query.getPageable(), searchHits.getTotalHits());
    }

    @Override
    public Page<T> page(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort, String... fields) {
        SearchHits<T> searchHits = this.searchHits(index, entityClass, param, pageable, sort, fields);
        List<SearchHit<T>> hits = searchHits.getSearchHits();
        List<T> list = new ArrayList<>();
        for (SearchHit<T> hit : hits) {
            list.add(hit.getContent());
        }
        pageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);
        return new PageImpl<T>(list, pageable, searchHits.getTotalHits());
    }

    @Override
    public Page<T> page(String index, Class<T> entityClass, String param, Pageable pageable) {
        return page(index, entityClass, param, pageable, pageable.getSort());
    }

    private NativeSearchQuery nativeSearchQuery(QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder) {
        Assert.notNull(aggregationBuilder, "'aggregationBuilder' cannot be 'null'");
        if (null == queryBuilder) {
            return new NativeSearchQueryBuilder().withMaxResults(0).addAggregation(aggregationBuilder).build();
        }
        return new NativeSearchQueryBuilder().withQuery(queryBuilder)
                .withMaxResults(0).addAggregation(aggregationBuilder).build();
    }
}
