/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.elasticserch.service;

import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.NativeSearchQuery;
import org.springframework.lang.Nullable;

import java.util.List;
import java.util.Map;

/**
 * @author tomoncle
 */
public interface ESQueryService<T> {
    /**
     * @param queryBuilder       // 构建查询条件, 根据result属性模糊查询
     *                           QueryBuilder queryBuilder = QueryBuilders
     *                           .boolQuery().must(QueryBuilders.wildcardQuery("result", "*" + word + "*"));
     * @param aggregationBuilder // 构建聚合查询条件，根据result属性进行分组，并根据统计值进行倒序排序
     *                           TermsAggregationBuilder mb = AggregationBuilders
     *                           .terms("group_by_result")
     *                           .field("result")
     *                           .size(10)
     *                           .order(BucketOrder.count(false));
     * @param entityClass        Entity.class
     * @return Map<String, List < ? extends Terms.Bucket>>
     */
    Map<String, List<? extends Terms.Bucket>> map(@Nullable QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder, Class<T> entityClass);

    /**
     * @param queryBuilder       // 构建查询条件, 根据result属性模糊查询
     *                           QueryBuilder queryBuilder = QueryBuilders
     *                           .boolQuery().must(QueryBuilders.wildcardQuery("result", "*" + word + "*"));
     * @param aggregationBuilder // 构建聚合查询条件，根据result属性进行分组，并根据统计值进行倒序排序
     *                           TermsAggregationBuilder mb = AggregationBuilders
     *                           .terms("group_by_result")
     *                           .field("result")
     *                           .size(10)
     *                           .order(BucketOrder.count(false));
     * @param entityClass        Entity.class
     * @return Aggregations
     */
    Aggregations aggregations(@Nullable QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder, Class<T> entityClass);

    /**
     * @param queryBuilder       // 构建查询条件, 根据result属性模糊查询
     *                           QueryBuilder queryBuilder = QueryBuilders
     *                           .boolQuery().must(QueryBuilders.wildcardQuery("result", "*" + word + "*"));
     * @param aggregationBuilder // 构建聚合查询条件，根据result属性进行分组，并根据统计值进行倒序排序
     *                           TermsAggregationBuilder mb = AggregationBuilders
     *                           .terms("group_by_result")
     *                           .field("result")
     *                           .size(10)
     *                           .order(BucketOrder.count(false));
     * @param entityClass        Entity.class
     * @param indexName          test / 支持 test* 这种前缀查询批量索引
     * @return Aggregations
     */
    Aggregations aggregations(@Nullable QueryBuilder queryBuilder, TermsAggregationBuilder aggregationBuilder, Class<T> entityClass, String indexName);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param query       // 查询条件 "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}";
     *                    QueryBuilder queryBuilder = QueryBuilders.boolQuery().must(QueryBuilders.matchAllQuery());
     *                    //  分页
     *                    PageRequest pageRequest = PageRequest.of(0, 5);
     *                    <p>
     *                    // 查询返回指定的字段
     *                    String[] fields = {"docId", "result"};
     *                    //
     *                    NativeSearchQuery query = new NativeSearchQueryBuilder().withQuery(queryBuilder)
     *                    .withPageable(pageRequest)
     *                    .withSort(SortBuilders.fieldSort("result").order(SortOrder.DESC))
     *                    .withSort(SortBuilders.fieldSort("_id").order(SortOrder.ASC))
     *                    .withFields(fields)
     *                    .build();
     * @return SearchHits<T>
     */
    SearchHits<T> searchHits(String index, Class<T> entityClass, NativeSearchQuery query);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param param       "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}"
     * @param pageable    PageRequest.of(0, 5)
     * @param sort        Sort.by(Sort.Direction.DESC, "result").and(Sort.by(Sort.Direction.ASC, "_id"))
     * @return SearchHits<T>
     */
    SearchHits<T> searchHits(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param param       "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}"
     * @param pageable    PageRequest.of(0, 5)
     * @param sort        Sort.by(Sort.Direction.DESC, "result").and(Sort.by(Sort.Direction.ASC, "_id"))
     * @param fields      {"id","result"}
     * @return SearchHits<T>
     */
    SearchHits<T> searchHits(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort, String... fields);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param query       NativeSearchQuery
     * @return List<T>
     */
    List<T> list(String index, Class<T> entityClass, NativeSearchQuery query);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param param       "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}"
     * @param pageable    PageRequest.of(0, 5)
     * @param sort        Sort.by(Sort.Direction.DESC, "result").and(Sort.by(Sort.Direction.ASC, "_id"))
     * @param fields      {"id","result"}
     * @return List<T>
     */
    List<T> list(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort, String... fields);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param param       "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}"
     * @param pageable    PageRequest.of(0, 5)
     * @return List<T>
     */
    List<T> list(String index, Class<T> entityClass, String param, Pageable pageable);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param query       NativeSearchQuery
     * @return Page<T>
     */
    Page<T> page(String index, Class<T> entityClass, NativeSearchQuery query);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param param       "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}"
     * @param pageable    PageRequest.of(0, 5)
     * @param sort        Sort.by(Sort.Direction.DESC, "result").and(Sort.by(Sort.Direction.ASC, "_id"))
     * @param fields      {"id","result"}
     * @return Page<T>
     */
    Page<T> page(String index, Class<T> entityClass, String param, Pageable pageable, Sort sort, String... fields);

    /**
     * @param index       test / 支持 test* 这种前缀查询批量索引
     * @param entityClass Entity.class
     * @param param       "{\"bool\":{\"must\":[{\"match_all\":{}}]}}}"
     * @param pageable    PageRequest.of(0, 5)
     * @return Page<T>
     */
    Page<T> page(String index, Class<T> entityClass, String param, Pageable pageable);
}
