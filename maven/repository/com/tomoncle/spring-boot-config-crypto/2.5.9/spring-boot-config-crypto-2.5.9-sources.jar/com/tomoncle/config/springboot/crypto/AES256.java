/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.crypto;

import org.cryptonode.jncryptor.AES256JNCryptor;
import org.cryptonode.jncryptor.CryptorException;
import org.cryptonode.jncryptor.JNCryptor;

import java.util.Base64;

/**
 * AES 算法的块大小为 128 位，无论您的密钥长度是 256、192 还是 128 位。
 * <p>
 * 当对称密码模式需要 IV 时，IV 的长度必须等于密码的块大小。因此，您必须始终对 AES 使用 128 位（16 字节）的 IV。
 * <p>
 * 没有办法在 AES 中使用 32 字节的 IV。
 *
 * @author tomoncle
 */
public class AES256 {
    private final String defaultEncryptPassword;
    private final JNCryptor crypto;

    public AES256(String encryptionPassword) {
        crypto = new AES256JNCryptor();
        defaultEncryptPassword = encryptionPassword;


    }

    public AES256() {
        this("}t¸ӷQ⸦}SPͱ±8ɾVϷBve3=·Yf");
    }


    /**
     * 获得加密数据
     *
     * @param plaintext 要加密的数据
     * @return 密文
     */
    public String cipherText(String plaintext) {
        try {
            return Base64.getEncoder().encodeToString(crypto.encryptData(plaintext.getBytes(), defaultEncryptPassword.toCharArray()));
        } catch (CryptorException ignored) {
        }
        return null;
    }

    /**
     * 获得明文数据
     *
     * @param cipherText 密文
     * @return 加密前的数据
     */
    public String plaintext(String cipherText) {
        try {
            return new String(crypto.decryptData(Base64.getDecoder().decode(cipherText), defaultEncryptPassword.toCharArray()));
        } catch (CryptorException ignored) {
        }
        return null;
    }


}
