/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.hikaricp;

import com.tomoncle.config.springboot.constant.SpringBootConfig;
import com.tomoncle.config.springboot.constant.SpringBootDataSourceProperties;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.sql.DataSource;

/**
 * HikariCP configuration
 * Created by liyuanjun on 18-5-25.
 */
@Configuration
@ConditionalOnProperty(
        prefix = SpringBootConfig.CONFIG_PREFIX,
        value = {"datasource.type"},
        havingValue = "hikaricp"
)
@EnableConfigurationProperties({HikariDataSourceProperties.class, SpringBootDataSourceProperties.class})
public class EnableHikariDataSourceConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(EnableHikariDataSourceConfiguration.class);

    @Primary
    @Bean(name = "hikariConfig")
    public HikariConfig hikariConfig(HikariDataSourceProperties properties) {
        LOGGER.info("initial HikariConfig bean.");
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(properties.getUrl());
        config.setUsername(properties.getUsername());
        config.setPassword(properties.getPassword());
        config.setDriverClassName(properties.getDriverClassName());
        config.setMaximumPoolSize(properties.getMaximumPoolSize());
        if (properties.getMinimumIdle() > 0) {
            config.setMinimumIdle(properties.getMinimumIdle());
        }
        config.setIdleTimeout(properties.getIdleTimeout());
        config.setConnectionTimeout(properties.getConnectionTimeout());
        config.setMaxLifetime(properties.getMaxLifetime());
        config.setAutoCommit(properties.isAutoCommit());
        config.setReadOnly(properties.isReadOnly());
        config.setConnectionTestQuery(properties.getConnectionTestQuery());
//        config.addDataSourceProperty("cachePrepStmts", "true");
//        config.addDataSourceProperty("prepStmtCacheSize", "250");
//        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        return config;
    }


    @Primary
    @Bean(name = "hikariDataSource")
    public DataSource hikariDataSource(HikariConfig hikariConfig) {
        LOGGER.info("initial HikariDataSource bean.");
        return new HikariDataSource(hikariConfig);
    }
}
