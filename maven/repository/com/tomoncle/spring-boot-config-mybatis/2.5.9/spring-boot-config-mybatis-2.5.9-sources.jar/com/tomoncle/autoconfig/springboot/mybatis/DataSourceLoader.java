/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.autoconfig.springboot.mybatis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import javax.sql.DataSource;


/**
 * 数据源加载器,弃用
 * Created by tom.lee on 2017/12/2.
 */

@Deprecated
//@Configuration
public class DataSourceLoader {
    private static final Logger logger = LoggerFactory.getLogger(DataSourceLoader.class);

    /**
     * 注入DruidDataSource
     */
    public DataSource getDataSource(ApplicationContext applicationContext) {
        DataSource dataSource = null;
        try {
            Object ex = applicationContext.getBean("druidDataSource");
            dataSource = (DataSource) ex;
        } catch (Exception e) {
            logger.error("加载连接池失败：" + e.getMessage());
            System.exit(1);
        }
        return dataSource;
    }

}
