/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.autoconfig.springboot.mybatis;

import com.tomoncle.config.springboot.constant.SpringBootConfig;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author tomoncle
 */
@Data
@ConfigurationProperties(prefix = SpringBootConfig.CONFIG_PREFIX + ".mybatis")
public class ConfigMybatisProperties {
    private ScannerType scannerType = ScannerType.packages;
    private Config config;

    public enum ScannerType {
        annotations,
        interfaces,
        packages
    }

    @Data
    public static class Config {
        private String typeAliasesPackage;
        private String sqlType;
        private String basePackage;
        private String mapperLocations;
        private String configLocation;
    }
}
