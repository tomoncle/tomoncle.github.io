/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.autoconfig.springboot.mybatis;

import com.google.common.base.CaseFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

/**
 * Mybatis Mapper 自动配置
 *
 * @author tomoncle
 * org.mybatis.spring.boot.autoconfigure.MybatisAutoConfiguration
 */
@AutoConfigureOrder(Ordered.LOWEST_PRECEDENCE)
@Configuration
@AutoConfigureAfter(ConfigMybatisConfiguration.class)
public class ConfigMapperScanner implements EnvironmentAware {
    private static final Logger logger = LogManager.getLogger(ConfigMapperScanner.class);
    private Environment environment;

    public ConfigMapperScanner() {
        logger.debug("init ConfigMapperScanner.");
    }


    /**
     * 自定义 MapperScannerConfigurer 配置
     * <p>
     * 注入这个Bean时，会导致当前配置类 ConfiguredMapperScannerConfigurer 存在以下几个问题：
     * <p>
     * 1.不能使用有参构造注入，必须使用无参构造
     * 2.不能使用 @Autowired 注解，注入 spring Bean，即便 Bean 不为null，属性值也不能setter成功, 都是默认值
     * 3.不能使用 BeanFactory 获取 spring Bean ，即便 Bean 不为null，属性值也不能setter成功, 都是默认值
     * 4.由于以上1，2，3存在的问题，只能使用"环境变量"加载配置文件中的配置
     * -- 4.1 方法一：实现 implements EnvironmentAware 接口
     * -- 4.2 方法二：实现 implements ApplicationContextAware 接口
     * <p>
     * 综上，该Bean配置和 SqlSessionFactoryBean、DataSourceTransactionManager 等Bean配置，不能在一个类中加载，会影响其他配置加载
     *
     * @return {@link MapperScannerConfigurer}
     */
    @Bean
    public MapperScannerConfigurer mapperScannerConfigurer() {
        logger.debug("init MapperScannerConfigurer.");
        MapperScannerConfigurer mapperScannerConfigurer = new MapperScannerConfigurer();
        // 配置 sqlSessionFactoryBean
        mapperScannerConfigurer.setSqlSessionFactoryBeanName("sqlSessionFactoryBean");
        // 扫描指定包下的Dao接口，使其自动注入; 必须的参数
        mapperScannerConfigurer.setBasePackage(this.getProperty("config.basePackage"));

        String type = this.getProperty("scannerType");
        ConfigMybatisProperties.ScannerType scannerType = StringUtils.hasText(type)
                ? ConfigMybatisProperties.ScannerType.valueOf(type) : ConfigMybatisProperties.ScannerType.packages;
        switch (scannerType) {
            case interfaces:
                // 扫描实现该接口的类，自动注入
                mapperScannerConfigurer.setMarkerInterface(MyBatisRepository.class);
                break;
            case annotations:
                // 扫描使用该注解的类, 自动注入；默认使用org.apache.ibatis.annotations.Mapper注解自动注入
                mapperScannerConfigurer.setAnnotationClass(MyBatisRepository.class);
                break;
            case packages:
            default:
        }
        return mapperScannerConfigurer;
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.environment = environment;
        logger.trace("{}", environment.getProperty("ignore-warning", "load environment."));
    }

    /**
     * 通过环境变量获取 mybatis 配置
     *
     * @param key {@link ConfigMybatisProperties}
     * @return value
     */
    private String getProperty(String key) {
        key = "spring.boot.config.mybatis." + key;
        return StringUtils.hasText(environment.getProperty(key)) ?
                environment.getProperty(key) :
                environment.getProperty(CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_HYPHEN, key));
    }

    /**
     * 自动配置 @MapperScan("com.tomoncle.test.mybatis.mapper")
     *
     * @see tk.mybatis.spring.annotation.MapperScan
     * @see tk.mybatis.spring.annotation.MapperScannerRegistrar#registerBeanDefinitions
     */
    @Configuration
    @Import(AutoInitializingBeanRegistrar.class)
    @ConditionalOnClass(name = "tk.mybatis.spring.mapper.ClassPathMapperScanner")
    public static class AutoInitializingBeanRegistrarNotFoundConfiguration implements InitializingBean {
        @Override
        public void afterPropertiesSet() {
        }
    }

}
