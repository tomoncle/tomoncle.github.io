/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.tomcat;

import com.tomoncle.config.springboot.constant.SpringBootConfig;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.core.AprLifecycleListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

import java.util.Collection;
import java.util.Collections;

/**
 * successful logs looks like this:
 * <p>
 * Loaded APR based Apache Tomcat Native library [1.2.23] using APR version [1.7.0].
 * APR capabilities: IPv6 [true], sendfile [true], accept filters [false], random [true].
 * APR/OpenSSL configuration: useAprConnector [true], useOpenSSL [true]
 * OpenSSL successfully initialized [OpenSSL 1.1.1c  28 May 2019]
 * ......
 * Starting ProtocolHandler ["http-apr-8080"]
 *
 * @author liyuanjun
 */
@AutoConfigureOrder(Ordered.HIGHEST_PRECEDENCE)
@Configuration
@ConditionalOnWebApplication
@ConditionalOnProperty(
        prefix = SpringBootConfig.CONFIG_PREFIX,
        value = {"tomcat.protocol"},
        havingValue = "APR"
)
@EnableConfigurationProperties({ConfigProperties.class})
public class ConfigurableTomcat implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {
    private final Logger logger = LoggerFactory.getLogger(ConfigurableTomcat.class);

    private final ConfigProperties configProperties;

    public ConfigurableTomcat(ConfigProperties configProperties) {
        this.configProperties = configProperties;
    }

    @Override
    public void customize(TomcatServletWebServerFactory factory) {
        // set Apr runtime
        factory.setProtocol("org.apache.coyote.http11.Http11AprProtocol");
        factory.setContextLifecycleListeners(getContextLifecycleListeners());
        logger.info("Tomcat container enable APR running mode.");
    }

    public Collection<? extends LifecycleListener> getContextLifecycleListeners() {
        // https://stackoverflow.com/questions/49809345/tomcat-with-apr-still-says-aprconnector-is-false
        final AprLifecycleListener aprLifecycleListener = new AprLifecycleListener();
        if (configProperties.isUseAprConnector()) {
            aprLifecycleListener.setUseAprConnector(true);
        }
        if (!configProperties.isSslEngine()) {
            aprLifecycleListener.setSSLEngine("off");
        }
        if (!configProperties.isUseOpenSSL()) {
            aprLifecycleListener.setUseOpenSSL(configProperties.isUseOpenSSL());
        }
        return Collections.singleton(aprLifecycleListener);
    }
}
