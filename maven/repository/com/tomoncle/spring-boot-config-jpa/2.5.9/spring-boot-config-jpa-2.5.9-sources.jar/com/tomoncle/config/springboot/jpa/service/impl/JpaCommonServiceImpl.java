/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.jpa.service.impl;

import com.tomoncle.config.springboot.jpa.JpaTransactional;
import com.tomoncle.config.springboot.jpa.service.JpaCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.io.Serializable;
import java.util.List;

/**
 * 抽象service基类实现: public class CustomerServiceImpl extends JpaCommonServiceImpl<Customer, Integer> implements CustomerService {}
 * <p/>
 * Created by liyuanjun on 18-5-31.
 */
public class JpaCommonServiceImpl<T, ID extends Serializable> extends JpaTransactional implements JpaCommonService<T, ID> {

    @SuppressWarnings("all")
    @Autowired
    JpaRepository<T, ID> jpaRepository;

    @Override
    public <S extends T> S findOne(Example<S> example) {
        return jpaRepository.findOne(example).orElse(null);
    }

    @Override
    public <S extends T> Page<S> findAll(Example<S> example, Pageable pageable) {
        return jpaRepository.findAll(example, pageable);
    }

    @Override
    public <S extends T> long count(Example<S> example) {
        return jpaRepository.count(example);
    }

    @Override
    public <S extends T> boolean exists(Example<S> example) {
        return jpaRepository.exists(example);
    }

    @Override
    public <S extends T> S save(S entity) {
        return jpaRepository.save(entity);
    }

    @Override
    public T findOne(ID id) {
        return jpaRepository.getById(id);
    }

    @Override
    public boolean exists(ID id) {
        return jpaRepository.existsById(id);
    }

    @Override
    public long count() {
        return jpaRepository.count();
    }

    @Override
    public void delete(ID id) {
        jpaRepository.deleteById(id);
    }

    @Override
    public void delete(T entity) {
        jpaRepository.delete(entity);
    }

    @Override
    public void delete(Iterable<? extends T> entities) {
        jpaRepository.deleteAll(entities);
    }

    @Override
    public void deleteAll() {
        jpaRepository.deleteAll();
    }

    @Override
    public Page<T> findAll(Pageable pageable) {
        return jpaRepository.findAll(pageable);
    }

    @Override
    public List<T> findAll() {
        return jpaRepository.findAll();
    }

    @Override
    public List<T> findAll(Sort sort) {
        return jpaRepository.findAll(sort);
    }

    @Override
    public List<T> findAll(Iterable<ID> ids) {
        return jpaRepository.findAllById(ids);
    }

    @Override
    public <S extends T> List<S> save(Iterable<S> entities) {
        return jpaRepository.saveAll(entities);
    }

    @Override
    public void flush() {
        jpaRepository.flush();
    }

    @Override
    public <S extends T> S saveAndFlush(S entity) {
        return jpaRepository.saveAndFlush(entity);
    }

    @Override
    public void deleteInBatch(Iterable<T> entities) {
        jpaRepository.deleteAllInBatch(entities);
    }

    @Override
    public void deleteAllInBatch() {
        jpaRepository.deleteAllInBatch();
    }

    @Override
    public T getOne(ID id) {
        return jpaRepository.getById(id);
    }

    @Override
    public <S extends T> List<S> findAll(Example<S> example) {
        return jpaRepository.findAll(example);
    }

    @Override
    public <S extends T> List<S> findAll(Example<S> example, Sort sort) {
        return jpaRepository.findAll(example, sort);
    }
}
