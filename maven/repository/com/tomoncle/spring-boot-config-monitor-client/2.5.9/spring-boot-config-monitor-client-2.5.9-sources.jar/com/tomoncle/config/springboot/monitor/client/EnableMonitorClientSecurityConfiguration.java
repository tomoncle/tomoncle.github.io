/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.monitor.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * 启用安全验证
 * <p>
 * application.properties:
 * <p>
 * ## 服务端配置　可以访问受保护的客户端端点
 * spring.boot.admin.client.metadata.user.name=${security.user.name}
 * spring.boot.admin.client.metadata.user.password=${security.user.password}
 * <p>
 * <p>
 * ## 客户端配置
 * # 配置客户端的用户名密码
 * spring.security.user.name=clientUser
 * spring.security.user.password=123456
 * # 向受保护的服务器API上注册，配置服务端登陆密码
 * spring.boot.admin.client.username=serverUser
 * spring.boot.admin.client.password=123456
 * <p>
 *
 * @author tomoncle
 */
@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties({SecurityProperties.class})
public class EnableMonitorClientSecurityConfiguration extends WebSecurityConfigurerAdapter {
    private static final Logger logger = LoggerFactory.getLogger(EnableMonitorClientSecurityConfiguration.class);
    private final SecurityProperties security;

    public EnableMonitorClientSecurityConfiguration(SecurityProperties security) {
        this.security = security;
        logger.info("Initializing springboot config admin client security configuration.");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 如果是自动生成的密码，则认为没有主动设置开启 security, 忽略访问认证
        if (security.getUser().isPasswordGenerated()) {
            http.logout().logoutUrl("#");
            http.headers().frameOptions().disable();
            http.authorizeRequests()
                    .antMatchers("**").permitAll() // 只能放行get请求
                    .and().csrf().disable(); // 放行 post等其他请求
        } else {
            super.configure(http);
        }

    }

}
