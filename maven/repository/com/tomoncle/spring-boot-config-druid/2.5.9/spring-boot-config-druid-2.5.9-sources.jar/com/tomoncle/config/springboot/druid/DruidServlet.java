//package com.tomoncle.config.springboot.druid;
//
//import com.alibaba.druid.support.http.StatViewServlet;
//import com.alibaba.druid.support.http.WebStatFilter;
//import com.alibaba.druid.support.spring.stat.DruidStatInterceptor;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.aop.support.DefaultPointcutAdvisor;
//import org.springframework.aop.support.JdkRegexpMethodPointcut;
//import org.springframework.boot.web.servlet.FilterRegistrationBean;
//import org.springframework.boot.web.servlet.ServletRegistrationBean;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Scope;
//import org.springframework.web.filter.CharacterEncodingFilter;
//
//import java.sql.SQLException;
//import java.util.HashMap;
//import java.util.Map;
//
//// 1.3.3.RELEASE
////import org.springframework.boot.context.embedded.FilterRegistrationBean;
////import org.springframework.boot.context.embedded.ServletRegistrationBean;
//
//// web 项目匹配
////import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
//
///**
// * ConditionalOnWebApplication 当前项目是Web项目的条件下配置该bean
// * <p/> https://blog.csdn.net/flyfish778/article/details/53470683
// * 配置druid连接池web监控信息
// * <p/>
// * 注销该配置，转移配置信息到　EnableDruidServletConfiguration.java
// * <p/>
// * Created by tom.lee on 2017/12/2.
// */
//@Deprecated
////@Configuration
////@ConditionalOnWebApplication
//public class DruidServlet {
//    private Logger logger = LoggerFactory.getLogger(DruidServlet.class);
//
//    /**
//     * 注册WebStatFilter到系统过滤器链
//     *
//     * @param ds
//     * @return
//     */
//    @Bean
//    public FilterRegistrationBean druidWebStatFilter(DruidConfigurationProperties ds) {
//        this.logger.info("init aric.springboot.config.druid druidWebStatFilter......");
//        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
//        // WebStatFilter用于采集web-jdbc关联监控的数据。
//        filterRegistrationBean.setFilter(new WebStatFilter());
//        Map<String, String> initParameters = new HashMap<>(1);
//        initParameters.put("exclusions", ds.getExclusions());
//        initParameters.put("sessionStatMaxCount", ds.getSessionStatMaxCount().toString());
//        initParameters.put("sessionStatEnable", String.valueOf(ds.isSessionStatEnable()));
//        if (ds.getPrincipalSessionName() != null) {
//            initParameters.put("principalSessionName", ds.getPrincipalSessionName());
//        }
//
//        initParameters.put("profileEnable", String.valueOf(ds.isProfileEnable()));
//        filterRegistrationBean.setInitParameters(initParameters);
//        return filterRegistrationBean;
//    }
//
//    /**
//     * 注册编码过滤器
//     *
//     * @return
//     */
//    @Bean
//    public FilterRegistrationBean charsetEncodingFilter() {
//        this.logger.info("init aric.springboot.config.druid charsetEncodingFilter......");
//        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
//        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
//        characterEncodingFilter.setEncoding("UTF-8");
//        filterRegistrationBean.setOrder(-2147483648);
//        filterRegistrationBean.setFilter(characterEncodingFilter);
//        return filterRegistrationBean;
//    }
//
//    /**
//     * 注册StatViewServlet
//     * Druid内置提供了一个StatViewServlet用于展示Druid的统计信息。
//     * 这个StatViewServlet的用途包括：
//     * 提供监控信息展示的html页面
//     * 提供监控信息的JSON API
//     * 注意：使用StatViewServlet，建议使用druid 0.2.6以上版本
//     *
//     * @param ds
//     * @return
//     * @throws java.sql.SQLException
//     */
//    @Bean
//    public ServletRegistrationBean druidStatViewServlet(DruidConfigurationProperties ds) throws SQLException {
//        this.logger.info("init aric.springboot.config.druid druidStatViewServlet......");
//        String[] urlMappings = new String[]{"/druid/*"};
//        ServletRegistrationBean registrationBean = new ServletRegistrationBean(new StatViewServlet(), urlMappings);
//        Map<String, String> map = new HashMap<>();
//        map.put("resetEnable", String.valueOf(ds.isResetEnable()));
//        if (ds.isAuthentication()) {
//            if (ds.getLoginUsername() != null)
//                map.put("loginUsername", ds.getLoginUsername());
//
//            if (ds.getLoginPassword() != null)
//                map.put("loginPassword", ds.getLoginPassword());
//        }
//
//        if (ds.getJmxUrl() != null)
//            map.put("jmxUrl", ds.getJmxUrl());
//
//        if (ds.getJmxUsername() != null)
//            map.put("jmxUsername", ds.getJmxUsername());
//
//        if (ds.getJmxPassword() != null)
//            map.put("jmxPassword", ds.getJmxPassword());
//
//        registrationBean.setInitParameters(map);
//        return registrationBean;
//    }
//
//
//    /**
//     * druid spring监控 拦截器
//     *
//     * @return
//     */
//    @Bean
//    public DruidStatInterceptor druidStatInterceptor() {
//        return new DruidStatInterceptor();
//    }
//
//    /**
//     * druid spring监控 方法名正则匹配拦截配置
//     *
//     * @param ds
//     * @return
//     */
//    @Bean
//    @Scope("prototype")
//    public JdkRegexpMethodPointcut jdkRegexpMethodPointcut(DruidConfigurationProperties ds) {
//        JdkRegexpMethodPointcut druidStatPointcut = new JdkRegexpMethodPointcut();
//        if (ds.getSpringPatterns() != null && ds.getSpringPatterns().length() > 1) {
//            druidStatPointcut.setPatterns(ds.getSpringPatterns().replaceAll(" ", "").split(","));
//        }
//        return druidStatPointcut;
//    }
//
//    /**
//     * druid spring监控 aop配置
//     *
//     * @param druidStatInterceptor 拦截器
//     * @param druidStatPointcut    正则匹配
//     * @return
//     */
//    @Bean
//    public DefaultPointcutAdvisor druidStatAdvisor(DruidStatInterceptor druidStatInterceptor, JdkRegexpMethodPointcut druidStatPointcut) {
//        logger.info("init aric.springboot.config.druid DefaultPointcutAdvisor");
//        DefaultPointcutAdvisor defaultPointAdvisor = new DefaultPointcutAdvisor();
//        defaultPointAdvisor.setPointcut(druidStatPointcut);
//        defaultPointAdvisor.setAdvice(druidStatInterceptor);
//        return defaultPointAdvisor;
//    }
//
//
//}
