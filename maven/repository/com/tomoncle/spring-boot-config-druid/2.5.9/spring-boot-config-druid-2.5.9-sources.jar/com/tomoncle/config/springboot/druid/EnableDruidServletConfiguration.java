/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.druid;

import com.alibaba.druid.support.http.StatViewServlet;
import com.alibaba.druid.support.http.WebStatFilter;
import com.alibaba.druid.support.spring.stat.DruidStatInterceptor;
import com.tomoncle.config.springboot.constant.SpringBootConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.JdkRegexpMethodPointcut;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.web.filter.CharacterEncodingFilter;

import javax.servlet.Filter;
import javax.servlet.Servlet;
import java.util.HashMap;
import java.util.Map;

// 1.3.3.RELEASE
//import org.springframework.boot.context.embedded.FilterRegistrationBean;
//import org.springframework.boot.context.embedded.ServletRegistrationBean;

// web 项目匹配
//import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;

/**
 * ConditionalOnWebApplication 当前项目是Web项目的条件下配置该bean
 * <p/> https://blog.csdn.net/flyfish778/article/details/53470683
 * 配置druid连接池web监控信息
 * <p/>
 * ConditionalOnProperty 如果该value值为空，则返回false;
 * 如果值不为空，则将该值与havingValue指定的值进行比较,相同则@Configuration注解生效,即创建bean
 * matchIfMissing = true,表示假如value值不存在或没有配置，则@Configuration注解生效,即创建bean
 * <p/>
 * spring.boot.config.druid.web.enabled=true 启用,默认关闭
 * <p/>
 * Created by tom.lee on 2017/12/2.
 */
@Configuration
@ConditionalOnProperty(
        prefix = SpringBootConfig.CONFIG_PREFIX,
        value = {"druid.datasource.monitorEnabled"},
        havingValue = "true"
)
@EnableConfigurationProperties({DruidConfigurationProperties.class})
public class EnableDruidServletConfiguration {

    private Logger logger = LoggerFactory.getLogger(EnableDruidServletConfiguration.class);

    /**
     * 注册WebStatFilter到系统过滤器链
     *
     * @param ds DruidConfigurationProperties
     */
    @Bean
    public FilterRegistrationBean druidWebStatFilter(DruidConfigurationProperties ds) {
        this.logger.debug("init druidWebStatFilter");
        FilterRegistrationBean<Filter> filterRegistrationBean = new FilterRegistrationBean<>();
        // WebStatFilter用于采集web-jdbc关联监控的数据。
        filterRegistrationBean.setFilter(new WebStatFilter());
        Map<String, String> initParameters = new HashMap<>(1);
        initParameters.put("exclusions", ds.getExclusions());
        initParameters.put("sessionStatMaxCount", ds.getSessionStatMaxCount().toString());
        initParameters.put("sessionStatEnable", String.valueOf(ds.isSessionStatEnable()));
        if (null != ds.getPrincipalSessionName()) {
            initParameters.put("principalSessionName", ds.getPrincipalSessionName());
        }
        initParameters.put("profileEnable", String.valueOf(ds.isProfileEnable()));
        filterRegistrationBean.setInitParameters(initParameters);
        return filterRegistrationBean;
    }

    /**
     * 注册编码过滤器
     */
    @Bean
    public FilterRegistrationBean charsetEncodingFilter() {
        this.logger.debug("init charsetEncodingFilter");
        FilterRegistrationBean<Filter> filterRegistrationBean = new FilterRegistrationBean<>();
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setEncoding("UTF-8");
        filterRegistrationBean.setOrder(-2147483648);
        filterRegistrationBean.setFilter(characterEncodingFilter);
        return filterRegistrationBean;
    }

    /**
     * 注册StatViewServlet
     * Druid内置提供了一个StatViewServlet用于展示Druid的统计信息。
     * 这个StatViewServlet的用途包括：
     * 提供监控信息展示的html页面
     * 提供监控信息的JSON API
     * 注意：使用StatViewServlet，建议使用druid 0.2.6以上版本
     *
     * @param ds DruidConfigurationProperties
     */
    @Bean
    public ServletRegistrationBean druidStatViewServlet(DruidConfigurationProperties ds) {
        this.logger.debug("init druidStatViewServlet");
        String[] urlMappings = new String[]{"/druid/*"};
        ServletRegistrationBean<Servlet> registrationBean = new ServletRegistrationBean<>(new StatViewServlet(), urlMappings);
        Map<String, String> map = new HashMap<>();
        map.put("resetEnable", String.valueOf(ds.isResetEnable()));
        if (ds.isAuthentication()) {
            if (null != ds.getLoginUsername()) {
                map.put("loginUsername", ds.getLoginUsername());
            }
            if (null != ds.getLoginPassword()) {
                map.put("loginPassword", ds.getLoginPassword());
            }
        }
        if (null != ds.getJmxUrl()) {
            map.put("jmxUrl", ds.getJmxUrl());
        }
        if (null != ds.getJmxUsername()) {
            map.put("jmxUsername", ds.getJmxUsername());
        }
        if (null != ds.getJmxPassword()) {
            map.put("jmxPassword", ds.getJmxPassword());
        }
        registrationBean.setInitParameters(map);
        return registrationBean;
    }


    /**
     * druid spring监控 拦截器
     */
    @Bean
    public DruidStatInterceptor druidStatInterceptor() {
        logger.debug("init DruidStatInterceptor");
        return new DruidStatInterceptor();
    }

    /**
     * druid spring监控 方法名正则匹配拦截配置
     *
     * @param ds DruidConfigurationProperties
     */
    @Bean
    @Scope("prototype")
    public JdkRegexpMethodPointcut jdkRegexpMethodPointcut(DruidConfigurationProperties ds) {
        logger.debug("init JdkRegexpMethodPointcut");
        JdkRegexpMethodPointcut druidStatPointcut = new JdkRegexpMethodPointcut();
        if (ds.getSpringPatterns() != null && ds.getSpringPatterns().length() > 1) {
            druidStatPointcut.setPatterns(ds.getSpringPatterns().replaceAll(" ", "").split(","));
        }
        return druidStatPointcut;
    }

    /**
     * druid spring监控 aop配置
     *
     * @param druidStatInterceptor 拦截器
     * @param druidStatPointcut    正则匹配
     */
    @Bean
    public DefaultPointcutAdvisor druidStatAdvisor(DruidStatInterceptor druidStatInterceptor, JdkRegexpMethodPointcut druidStatPointcut) {
        logger.debug("init DefaultPointcutAdvisor");
        DefaultPointcutAdvisor defaultPointAdvisor = new DefaultPointcutAdvisor();
        defaultPointAdvisor.setPointcut(druidStatPointcut);
        defaultPointAdvisor.setAdvice(druidStatInterceptor);
        return defaultPointAdvisor;
    }


}
