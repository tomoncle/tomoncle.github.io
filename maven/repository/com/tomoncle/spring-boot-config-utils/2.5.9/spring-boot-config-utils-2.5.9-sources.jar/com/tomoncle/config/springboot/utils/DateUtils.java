/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.concurrent.TimeUnit;


/**
 * <p>描述信息：时间工具类
 *
 * <blockquote><pre>
 * // 上海时间
 * ZoneId shanghaiZoneId = ZoneId.of("Asia/Shanghai");
 * ZonedDateTime cstZonedDateTime = ZonedDateTime.now(shanghaiZoneId);
 *
 * // 伦敦时间
 * ZoneId utcZoneId = ZoneId.of("Europe/London");
 * ZonedDateTime utcZoneTime = ZonedDateTime.now(utcZoneId);
 *
 * DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
 * System.out.println("上海时间: " + cstZonedDateTime.format(formatter));
 * System.out.println("UTC时间: " + utcZoneTime.format(formatter));
 * </pre></blockquote>
 *
 * @author liyuanjun
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public final class DateUtils {
    private static final ZoneId CST_ZONE_ID = ZoneId.of("Asia/Shanghai");
    private static final ZoneId UTC_ZONE_ID = ZoneId.of("UTC");
    private static final String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern(DEFAULT_PATTERN);
    // 线程不安全，应该使用 ThreadLocal
    // private static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    /**
     * @param text 2020-11-12 10:00:00
     * @return 2020-11-12
     */
    public static LocalDate parseLocalDate(String text) {
        return LocalDate.parse(text, DATE_TIME_FORMATTER);
    }

    /**
     * @param text      2020-11-12 10:00:00
     * @param formatter yyyy-MM-dd HH:mm:ss
     * @return 2020-11-12
     */
    public static LocalDate parseLocalDate(String text, String formatter) {
        return LocalDate.parse(text, DateTimeFormatter.ofPattern(formatter));
    }

    /**
     * @param text 2007-12-03T02:23:30+08:00
     *             2007-12-03T10:15:30+01:00[Europe/Paris]
     * @return ZonedDateTime
     */
    public static ZonedDateTime parseZonedDateTime(String text) {
        return ZonedDateTime.parse(text);
    }

    /**
     * 获取当前时间
     *
     * @return ZonedDateTime
     */
    public static ZonedDateTime cstZonedNowDateTime() {
        return ZonedDateTime.now(CST_ZONE_ID);
    }

    /**
     * 获取当前时间
     *
     * @return Date
     */
    public static Date now() {
        return Date.from(cstZonedNowDateTime().toInstant());
    }

    public static LocalDateTime localDateTime(Long timestamp) {
        return localDateTime(timestamp, CST_ZONE_ID);
    }

    public static LocalDateTime localDateTime(Long timestamp, ZoneId zoneId) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(timestamp), zoneId);
    }

    public static String timestampFormat(Long timestamp) {
        return DATE_TIME_FORMATTER.format(localDateTime(timestamp));
    }

    public static String timestampFormat(Long timestamp, String format) {
        return timestampFormat(timestamp, format, CST_ZONE_ID);
    }

    public static String timestampFormat(Long timestamp, String format, ZoneId zoneId) {
        return DateTimeFormatter.ofPattern(format).format(localDateTime(timestamp, zoneId));
    }

    /**
     * @return 2020-11-20 09:46:07
     */
    public static String currentTimeString() {
        return currentTimeString(DEFAULT_PATTERN);
    }

    /**
     * 获取当前时间的 字符串格式，
     *
     * @param format "yyyy-MM-dd HH:mm:ss" "yyyy-MM-dd"
     * @return 2020-01-01
     */
    public static String currentTimeString(String format) {
        return cstZonedNowDateTime().format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * @param seconds 当前时间往前的秒数
     * @return 当前时间往前n秒的时间
     */
    public static Date nowMinusSeconds(int seconds) {
        return Date.from(cstZonedNowDateTimeMinusSeconds(seconds).toInstant());
    }

    /**
     * @param minutes 当前时间往前的分钟数
     * @return 当前时间往前n分钟的时间
     */
    public static Date nowMinusMinutes(int minutes) {
        return Date.from(cstZonedNowDateTime().minusMinutes(minutes).toInstant());
    }

    /**
     * @param hours 当前时间往前的小时数
     * @return 当前时间往前n小时的时间
     */
    public static Date nowMinusHours(int hours) {
        return Date.from(cstZonedNowDateTime().minusHours(hours).toInstant());
    }

    /**
     * @param days 当前时间往前的天数
     * @return 当前时间往前n天的时间
     */
    public static Date nowMinusDays(int days) {
        return Date.from(cstZonedNowDateTime().minusDays(days).toInstant());
    }

    /**
     * 获取当前时间 x秒 之前的时间
     *
     * @param seconds 秒
     * @return ZonedDateTime
     */
    public static ZonedDateTime cstZonedNowDateTimeMinusSeconds(int seconds) {
        return ZonedDateTime.now(CST_ZONE_ID).minusSeconds(seconds);
    }

    /**
     * @return utc 时间
     */
    public static ZonedDateTime utcZonedNowDateTime() {
        return ZonedDateTime.now(UTC_ZONE_ID);
    }

    /**
     * @param zonedDateTime DateUtils.cstZonedNowDateTime()
     * @return 2020-11-20 09:46:07
     */
    public static String format(ZonedDateTime zonedDateTime) {
        return zonedDateTime.format(DATE_TIME_FORMATTER);
    }

    /**
     * @param zonedDateTime DateUtils.cstZonedNowDateTime()
     * @return 2020-11-20T09:46:07
     */
    public static String formatT(ZonedDateTime zonedDateTime) {
        return format(zonedDateTime).replace(" ", "T");
    }

    /**
     * @param text 2020-11-20 09:46:07
     * @return Fri Nov 20 09:46:07 CST 2020
     */
    public static Date parseDate(String text) {
        return Date.from(LocalDateTime.parse(text, DATE_TIME_FORMATTER).atZone(CST_ZONE_ID).toInstant());
    }

    /**
     * @param text      2020-11-20 09:46:07       21/04/22-11:33:55
     * @param formatter yyyy-MM-dd HH:mm:ss       yy/MM/dd-HH:mm:ss
     * @return Fri Nov 20 09:46:07 CST 2020
     */
    public static Date parseDate(String text, String formatter) throws ParseException {
        return new SimpleDateFormat(formatter).parse(text);
    }

    /**
     * @param zonedDateTime DateUtils.cstZonedNowDateTime()
     * @return Fri Nov 20 09:46:07 CST 2020
     */
    public static Date parseDate(ZonedDateTime zonedDateTime) {
        return Date.from(zonedDateTime.toInstant());
    }

    /**
     * @param timeUnit TimeUnit
     * @return timestamp
     */
    public static Long timestamp(TimeUnit timeUnit) {
        switch (timeUnit) {
            case DAYS:
                return parse(currentTimeString("yyyy-MM-dd").concat(" 00:00:00"));
            case HOURS:
                return parse(currentTimeString("yyyy-MM-dd HH").concat(":00:00"));
            case MINUTES:
                return parse(currentTimeString("yyyy-MM-dd HH:mm").concat(":00"));
            case SECONDS:
            default:
                return parse(currentTimeString());
        }
    }

    /**
     * @param timeUnit TimeUnit
     * @param minus    当前时间往前偏移量
     * @return timestamp
     */
    public static Long timestampOfMinus(TimeUnit timeUnit, int minus) {
        switch (timeUnit) {
            case DAYS:
                return timestamp(timeUnit) - 86400L * minus;
            case HOURS:
                return timestamp(timeUnit) - 3600L * minus;
            case MINUTES:
                return timestamp(timeUnit) - 60L * minus;
            case SECONDS:
            default:
                return timestamp(timeUnit) - minus;
        }
    }

    /**
     * @param timeUnit TimeUnit
     * @param plus     当前时间往后偏移量
     * @return timestamp
     */
    public static Long timestampOfPlus(TimeUnit timeUnit, int plus) {
        switch (timeUnit) {
            case DAYS:
                return timestamp(timeUnit) + 86400L * plus;
            case HOURS:
                return timestamp(timeUnit) + 3600L * plus;
            case MINUTES:
                return timestamp(timeUnit) + 60L * plus;
            case SECONDS:
            default:
                return timestamp(timeUnit) + plus;
        }
    }

    private static Long parse(String dateString) {
        return parseDate(dateString).getTime() / 1000;
    }

}
