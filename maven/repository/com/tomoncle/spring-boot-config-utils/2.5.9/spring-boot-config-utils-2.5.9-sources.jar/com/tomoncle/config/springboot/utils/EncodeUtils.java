/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.utils;

import org.unbescape.html.HtmlEscape;
import org.unbescape.html.HtmlEscapeLevel;
import org.unbescape.html.HtmlEscapeType;

import java.nio.charset.Charset;
import java.util.Base64;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author tomoncle
 */
public final class EncodeUtils {
    private static final Base64.Decoder decoder = Base64.getDecoder();

    /**
     * @param escapedText "<title>&#51;&#54;&#53;&#20122;&#27954;&#26479;&#22806;&#22260;"
     * @return utf8
     */
    public static String unescape(String escapedText) {
        return HtmlEscape.unescapeHtml(escapedText);
    }

    /**
     * @param text utf8
     * @return &#54;&#53;&#20122;
     */
    public static String escape(String text) {
        return HtmlEscape.escapeHtml(text,
                HtmlEscapeType.DECIMAL_REFERENCES,
                HtmlEscapeLevel.LEVEL_4_ALL_CHARACTERS);
    }

    /**
     * @param unicode \\u6f0f\\u6d1e 或者 \\\\u6f0f\\\\u6d1e
     * @return utf8
     */
    public static String unicodeDecode(String unicode) {
        // http://netwjx.github.io/blog/2012/07/07/encode-and-decode-unicode-escape-string/
        Pattern reUnicode = Pattern.compile("\\\\u([0-9a-zA-Z]{4})");
        if (unicode.contains("\\\\u")) {
            reUnicode = Pattern.compile("\\\\\\\\u([0-9a-zA-Z]{4})");
        }
        Matcher m = reUnicode.matcher(unicode);
        StringBuffer sb = new StringBuffer(unicode.length());
        while (m.find()) {
            m.appendReplacement(sb, Character.toString((char) Integer.parseInt(m.group(1), 16)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    public static String unicodeEncode(String s) {
        StringBuilder sb = new StringBuilder(s.length() * 3);
        for (char c : s.toCharArray()) {
            if (c < 256) {
                sb.append(c);
            } else {
                sb.append("\\u");
                sb.append(Character.forDigit((c >>> 12) & 0xf, 16));
                sb.append(Character.forDigit((c >>> 8) & 0xf, 16));
                sb.append(Character.forDigit((c >>> 4) & 0xf, 16));
                sb.append(Character.forDigit((c) & 0xf, 16));
            }
        }
        return sb.toString();
    }

    public static String base64Decode(String base64) {
        return base64Decode(base64, Charset.forName("UTF-8"));
    }

    /**
     * 根据指定编码来解码内容
     *
     * @param base64  内容
     * @param charset 内容编码
     * @return 明文
     */
    public static String base64Decode(String base64, Charset charset) {
        String tempString = base64.replaceAll("\\s", "");
        return new String(decoder.decode(tempString), charset);
    }
}
