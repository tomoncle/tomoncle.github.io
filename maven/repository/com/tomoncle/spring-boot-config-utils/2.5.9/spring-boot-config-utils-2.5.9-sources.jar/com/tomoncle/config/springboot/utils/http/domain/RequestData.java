/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.utils.http.domain;

import com.alibaba.fastjson.JSONObject;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.RequestBody;

import java.util.Map;
import java.util.Objects;

public class RequestData {
    private final JSONObject value;
    private final DataType dataType;
    private final String json;

    private RequestData(JSONObject value, String json, DataType dataType) {
        this.value = value;
        this.json = json;
        this.dataType = dataType;
    }

    public static Builder builder(DataType dataType) {
        return new Builder(dataType);
    }

    public JSONObject getValue() {
        return value;
    }

    public DataType getDataType() {
        return dataType;
    }

    public String getJson() {
        return json;
    }

    /**
     * 解析map为 form string
     *
     * @param map Map
     * @return string
     */
    private FormBody formBody(Map<String, Object> map) {
        FormBody.Builder builder = new FormBody.Builder();
        for (String name : map.keySet()) {
            builder.add(name, map.get(name).toString());
        }
        return builder.build();
    }

    /**
     * 验证 RequestBody
     *
     * @param requestData data
     * @return RequestBody
     */
    private RequestBody buildRequestBody(RequestData requestData) {
        if (Objects.isNull(requestData)) {
            requestData = RequestData.builder(DataType.BODY).build();
        }
        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        switch (requestData.getDataType()) {
            case JSON:
                return RequestBody.create(requestData.getJson(), JSON);
            case FORM:
                return formBody(requestData.getValue());
            case BODY:
                return RequestBody.create(requestData.getValue().toJSONString(), JSON);
            default:
                return null;
        }
    }

    public RequestBody toRequestBody() {
        return buildRequestBody(this);
    }

    public static class Builder {
        private final JSONObject value;
        private final DataType dataType;
        private String json;

        Builder(DataType dataType) {
            this.dataType = dataType;
            this.value = new JSONObject();
            this.json = "{}";
        }

        public Builder setParam(String key, Object value) {
            if(dataType == DataType.JSON) {
                throw new UnsupportedOperationException("Only support BODY or FORM DataType !");
            }
            this.value.put(key, value);
            return this;
        }

        public Builder toJsonObject(Object javaObject) {
            if(dataType != DataType.JSON) {
                throw new UnsupportedOperationException("Only support JSON DataType !");
            }
            this.json = JSONObject.toJSONString(javaObject);
            return this;
        }

        public RequestData build() {
            return new RequestData(this.value, this.json, this.dataType);
        }
    }

}

