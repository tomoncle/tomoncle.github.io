/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.zuul.filter;


import com.tomoncle.config.springboot.zuul.mapper.IRouteMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * 使用过滤器自动切换代理地址，拦截所有请求
 * 并执行 RefreshRouteMapper 接口的实现来处理
 * Created by liyuanjun on 18-5-30.
 * <p/>
 * <p/>
 * 测试：
 * POST:
 * curl -X POST -F "website=sina" http://localhost:8601
 * 浏览器访问：http://localhost:8601/zuulProxy
 * <p/>
 * GET:
 * curl http://localhost:8601?website=qq
 * 浏览器访问：　http://localhost:8601/zuulProxy
 */
@Lazy
@AutoConfigureOrder(Ordered.LOWEST_PRECEDENCE)
@Configuration
@WebFilter(urlPatterns = "*", filterName = "zuulStorageRouteFilter")
@ConditionalOnWebApplication
public class ZuulStorageRouteFilter implements Filter {

    private static Logger logger = LoggerFactory.getLogger(ZuulStorageRouteFilter.class);

    // 注入自动刷新接口，允许为空
    // 当没有具体实现时，该功能即无效
    private @Autowired(required = false)
    IRouteMapper iRouteMapper;

    public ZuulStorageRouteFilter() {
        logger.info("Initial ZuulStorageRouteFilter.");
        if (null == iRouteMapper) {
            logger.warn("Cannot found bean type of IRouteMapper, the dynamic routing feature will not be available.");
        }
    }

    @Override
    public void init(FilterConfig filterConfig) {
        logger.debug("ZuulStorageRouteFilter execute init. IRouteMapper instance :" + iRouteMapper);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
                         FilterChain filterChain) throws IOException, ServletException {
        if (null != iRouteMapper) {
            logger.debug("ZuulStorageRouteFilter execute doFilter method.");
            // 拦截请求的具体实现
            iRouteMapper.refresh(servletRequest, servletResponse);
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {
        logger.debug("ZuulStorageRouteFilter execute destroy method.");
    }
}
