/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.monitor;

import de.codecentric.boot.admin.server.config.AdminServerProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.util.UUID;

/**
 * 启用安全验证
 * <p>
 * application.properties:
 * <p>
 * # 服务端配置　权限信息
 * spring.security.user.name=serverUser
 * spring.security.user.password=123456
 * spring.boot.config.admin.server.security.enable=true
 * logging.level.org.springframework.security: DEBUG
 * <p>
 * # 服务端配置　可以访问受保护的客户端端点
 * spring.boot.admin.client.metadata.user.name=${security.user.name}
 * spring.boot.admin.client.metadata.user.password=${security.user.password}
 * <p>
 * <p>
 * ## 客户端配置　向受保护的服务器API上注册，配置服务端登陆密码
 * spring.boot.admin.client.username=serverUser
 * spring.boot.admin.client.password=123456
 * <p>
 *
 * @author tomoncle
 */

@Configuration(proxyBeanMethods = false)
@EnableConfigurationProperties({
        AdminServerProperties.class,
        SecurityProperties.class
})
public class EnableMonitorSecurityConfiguration extends WebSecurityConfigurerAdapter {
    private static final Logger logger = LoggerFactory.getLogger(EnableMonitorSecurityConfiguration.class);

    private final AdminServerProperties adminServer;
    private final SecurityProperties security;

    public EnableMonitorSecurityConfiguration(AdminServerProperties adminServer, SecurityProperties security) {
        this.adminServer = adminServer;
        this.security = security;
        logger.info("Initializing springboot config security [{}] state.", security.getUser().isPasswordGenerated() ? "closed" : "opened");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        // 如果是自动生成的密码，则认为没有主动设置开启 security, 忽略访问认证
        if (security.getUser().isPasswordGenerated()) {
            http.logout().logoutUrl("#");
            // default: Refused to display in a frame because it set 'X-Frame-Options' to 'DENY'
            http.headers().frameOptions().disable();
            http.authorizeRequests()
                    .antMatchers("**").permitAll() // 只能放行get请求
                    .and().csrf().disable(); // 放行 post等其他请求
            return;
        }

        SavedRequestAwareAuthenticationSuccessHandler successHandler = new SavedRequestAwareAuthenticationSuccessHandler();
        successHandler.setTargetUrlParameter("redirectTo");
        successHandler.setDefaultTargetUrl(this.adminServer.path("/"));
        http.authorizeRequests((authorizeRequests) -> authorizeRequests
                        .antMatchers(this.adminServer.path("/assets/**")).permitAll()
                        .antMatchers(this.adminServer.path("/actuator/info")).permitAll()
                        .antMatchers(this.adminServer.path("/actuator/health")).permitAll()
                        .antMatchers(this.adminServer.path("/login")).permitAll()
                        .anyRequest().authenticated())
                .formLogin((formLogin) -> formLogin.loginPage(this.adminServer.path("/login")).successHandler(successHandler).and())
                .logout((logout) -> logout.logoutUrl(this.adminServer.path("/logout"))).httpBasic(Customizer.withDefaults())
                .csrf((csrf) -> csrf.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()).ignoringRequestMatchers(
                        new AntPathRequestMatcher(this.adminServer.path("/instances"), HttpMethod.POST.toString()),
                        new AntPathRequestMatcher(this.adminServer.path("/instances/*"), HttpMethod.DELETE.toString()),
                        new AntPathRequestMatcher(this.adminServer.path("/actuator/**"))
                )).rememberMe((rememberMe) -> rememberMe.key(UUID.randomUUID().toString()).tokenValiditySeconds(1209600));
    }

    // Required to provide UserDetailsService for "remember functionality"
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
                .withUser(security.getUser().getName())
                .password("{noop}" + security.getUser().getPassword())
                .roles("USER");
    }

}

