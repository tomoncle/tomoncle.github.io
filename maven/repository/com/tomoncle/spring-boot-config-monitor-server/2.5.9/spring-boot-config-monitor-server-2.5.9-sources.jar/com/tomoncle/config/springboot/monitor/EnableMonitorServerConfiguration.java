/*
 * Copyright 2018 tomoncle
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tomoncle.config.springboot.monitor;

import de.codecentric.boot.admin.server.config.EnableAdminServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

/**
 * 启用Spring Boot Admin
 * Created by liyuanjun on 18-5-16.
 */
@Configuration
@EnableAdminServer
public class EnableMonitorServerConfiguration {
    private static final Logger logger = LoggerFactory.getLogger(EnableMonitorServerConfiguration.class);

    public EnableMonitorServerConfiguration() {
        logger.info("Initializing springboot admin monitor server start.");
    }

//    /**
//     * 如果 spring.boot.config.admin.server.security.enable = false
//     * 则禁用 SpringSecurity
//     * <p>
//     * 目前这个配置没有生效，bean 成功注册，但是没有移除 SecurityAutoConfiguration
//     */
//    @Configuration
//    @ConditionalOnProperty(
//            value = {"spring.boot.config.admin.server.security.enable"},
//            matchIfMissing = true
//    )
//    @EnableAutoConfiguration(exclude = {
//            org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration.class
//    })
//    public class DisabledSecurityConfiguration {
//        public DisabledSecurityConfiguration() {
//            logger.info("disabled spring security auto configuration");
//        }
//    }


}

